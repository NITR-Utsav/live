<?php

class Client {
    public $NUID;
    public $name;
    public $college;
    public $contact;
    public $email;
    public $payment;
    public $attendance;
}

?>